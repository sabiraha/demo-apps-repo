
/**
 *
 * The classes in this package represent the JPA implementation
 * of PetClinic's persistence layer.
 *
 */
package org.springframework.samples.petclinic.repository.jpa;

